#include <stdio.h> 

int main() {
	int A[100][100];
	int n=5;

	//Filling the array
	srand(time(NULL));
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			Array[i][j] = rand() % 10;
		}
	}

	printf("Source array : \n");
	for (int i = 0; i < n; i++)
		for (int i = 0; i < n; i++)
		{
			printf("\n");
			for (int j = 0; j < n; j++)
			{
				printf("%d ", Array[i][j]);
			}
		}
	int cmin=0,cmax=0,min=0,max=0,k=0,h=0;
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			if (A[i][j] < 0) cmin++;
			if (A[j][i] > 0) cmax++;
		}
		if (min < cmin) {
			min = cmin;
			k = i;
		}
		if (max < cmax) {
			max = cmax;
			h = i;
		}
		cmin = 0;
		cmax = 0;
	}
	for (int i = 1; i <= n; i++) {
		if (i != k) {
			for (int j = 1; j <= n; j++) {
				if (j != h) printf("%d ",A[i][j]);
			}
			printf("\n");
		}
	}
	system("pause");
	return 0;
}
